const express = require('express');
const http = require('http');
const socketIO = require('socket.io');

const app = express();
const server = http.createServer(app);
const io = socketIO(server);
require('dotenv').config();


const bodyParser = require('body-parser');
const authRoutes = require('./routes/authRoutes');

// Middleware to parse JSON requests
app.use(bodyParser.json());
app.use(express.static(__dirname)); 


// Include authentication routes
app.use('/auth', authRoutes);

// Data structures to store poll options and chat messages
const pollOptions = [
    { id: 1, text: "Option 1", votes: 0 },
    { id: 2, text: "Option 2", votes: 0 },
    { id: 3, text: "Option 3", votes: 0 }
];

const chatMessages = [];
const pollResults = [0, 0, 0];

// WebSocket communication
io.on('connection', (socket) => {
    console.log('A user connected');

    // Send poll options to the client
    socket.emit('poll options', pollOptions);

    // Listen for chat messages and broadcast to all connected clients
    socket.on('chat message', (message) => {
        // Associate the message with the user's username 
        const chatMessage = { message };
        chatMessages.push(chatMessage);
        io.emit('chat message', chatMessage);
    });

    // Listen for votes and update poll results
socket.on('vote', (optionIndex) => {
  if (optionIndex === 0) { // Option 1
      pollResults[0]++;
  }else if(optionIndex === 1){
    pollResults[1]++;
  }else if(optionIndex === 2){
    pollResults[2]++;
  }
  // Send the updated results to all connected clients
  io.emit('poll results', pollResults);
});

    // Handle disconnections
    socket.on('disconnect', () => {
        console.log('A user disconnected');
    });
});

const port = process.env.PORT || 3000;
server.listen(port, () => {
    console.log(`Server is running on http://localhost:${port}`);
});

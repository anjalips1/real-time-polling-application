const jwt = require('jsonwebtoken');


const users = [
    { username: 'user1', password: 'password1' },
    { username: 'user2', password: 'password2' },
    { username: 'user3', password: 'password3' },
  ];
  
  function login(req, res) {
    const { username, password } = req.body;
    const secretKey = process.env.SECRET_KEY;
  
    const user = users.find(
      (user) => user.username === username && user.password === password
    );

    if (user) {
        const token = jwt.sign({ username }, secretKey, { expiresIn: '1h' });
        res.status(200).json({ success: true ,token , username});
    } else {
        res.status(401).json({ success: false, message: 'Invalid username or password' });
    }
  
  }
  
  module.exports = {
    login,
  };
  